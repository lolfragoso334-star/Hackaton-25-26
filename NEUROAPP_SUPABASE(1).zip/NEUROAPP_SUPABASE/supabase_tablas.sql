-- ══════════════════════════════════════════════════════════════
-- TABLAS NEUROVIDA — estructura real de la BD
-- Si ya tienes las tablas creadas, solo ejecuta las políticas RLS
-- Supabase → SQL Editor → New query → pegar y ejecutar
-- ══════════════════════════════════════════════════════════════

-- ── 1. PERFILES (vinculada a auth.users) ──
CREATE TABLE IF NOT EXISTS perfiles (
  id              uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nombre_completo text,
  rol             text NOT NULL DEFAULT 'usuario'   -- 'usuario' | 'admin'
);

-- ── 2. TAREAS ──
CREATE TABLE IF NOT EXISTS tareas (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo      text NOT NULL,
  descripcion text,
  creado_por  uuid REFERENCES perfiles(id) ON DELETE SET NULL
);

-- ── 3. PASOS ──
CREATE TABLE IF NOT EXISTS pasos (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tarea_id           uuid NOT NULL REFERENCES tareas(id) ON DELETE CASCADE,
  orden              int4 NOT NULL DEFAULT 1,
  instruccion_texto  text NOT NULL,
  imagen_url         text,
  es_critico         bool NOT NULL DEFAULT false
);

-- ── 4. REGISTROS DE PROGRESO ──
CREATE TABLE IF NOT EXISTS registros_progreso (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id  uuid NOT NULL REFERENCES perfiles(id) ON DELETE CASCADE,
  paso_id     uuid NOT NULL REFERENCES pasos(id)    ON DELETE CASCADE,
  fecha_inicio timestamptz DEFAULT now(),
  fecha_fin    timestamptz,
  estado      text NOT NULL DEFAULT 'pendiente'
               CHECK (estado IN ('pendiente', 'en_progreso', 'completado')),
  UNIQUE (usuario_id, paso_id)   -- un registro por usuario y paso
);

-- ══════════════════════════════════════════════════════════════
-- POLÍTICAS RLS
-- Ejecuta esto si las tablas ya existen y solo necesitas configurar acceso
-- ══════════════════════════════════════════════════════════════

ALTER TABLE perfiles           ENABLE ROW LEVEL SECURITY;
ALTER TABLE tareas             ENABLE ROW LEVEL SECURITY;
ALTER TABLE pasos              ENABLE ROW LEVEL SECURITY;
ALTER TABLE registros_progreso ENABLE ROW LEVEL SECURITY;

-- PERFILES: cada usuario ve y edita solo su perfil
CREATE POLICY "ver_propio_perfil"   ON perfiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "editar_propio_perfil" ON perfiles FOR UPDATE USING (auth.uid() = id);

-- TAREAS: todos los usuarios autenticados pueden leer
CREATE POLICY "leer_tareas" ON tareas FOR SELECT TO authenticated USING (true);
-- Solo admins pueden crear/editar/borrar tareas
CREATE POLICY "admin_insertar_tareas" ON tareas FOR INSERT TO authenticated
  WITH CHECK ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "admin_actualizar_tareas" ON tareas FOR UPDATE TO authenticated
  USING ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "admin_borrar_tareas" ON tareas FOR DELETE TO authenticated
  USING ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');

-- PASOS: todos pueden leer, solo admins modifican
CREATE POLICY "leer_pasos" ON pasos FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin_insertar_pasos" ON pasos FOR INSERT TO authenticated
  WITH CHECK ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "admin_actualizar_pasos" ON pasos FOR UPDATE TO authenticated
  USING ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "admin_borrar_pasos" ON pasos FOR DELETE TO authenticated
  USING ((SELECT rol FROM perfiles WHERE id = auth.uid()) = 'admin');

-- REGISTROS_PROGRESO: cada usuario gestiona su propio progreso
CREATE POLICY "ver_propio_progreso" ON registros_progreso FOR SELECT
  USING (auth.uid() = usuario_id);
CREATE POLICY "insertar_propio_progreso" ON registros_progreso FOR INSERT
  WITH CHECK (auth.uid() = usuario_id);
CREATE POLICY "actualizar_propio_progreso" ON registros_progreso FOR UPDATE
  USING (auth.uid() = usuario_id);

-- ══════════════════════════════════════════════════════════════
-- ALTERNATIVA RÁPIDA PARA HACKATHON (sin autenticación)
-- Descomenta estas líneas si prefieres acceso público sin login
-- ══════════════════════════════════════════════════════════════
-- CREATE POLICY "publico_tareas"    ON tareas             FOR ALL TO anon USING (true) WITH CHECK (true);
-- CREATE POLICY "publico_pasos"     ON pasos              FOR ALL TO anon USING (true) WITH CHECK (true);
-- CREATE POLICY "publico_progreso"  ON registros_progreso FOR ALL TO anon USING (true) WITH CHECK (true);
