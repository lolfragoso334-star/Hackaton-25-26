/* ══════════════════════════════════════════════════════════════
   TAREAS — NeuroVida  (conectado a Supabase)
   Estructura real:
     tareas            : id, titulo, descripcion, creado_por
     pasos             : id, tarea_id, orden, instruccion_texto, imagen_url, es_critico
     registros_progreso: id, usuario_id, paso_id, fecha_inicio, fecha_fin, estado
   El "estado" de un paso para un usuario se guarda en registros_progreso.
══════════════════════════════════════════════════════════════ */
import { sb } from './supabase.js';

let tareas       = [];
let progreso     = {};   // { [paso_id]: estado }  del usuario actual
let usuarioId    = null;
let filtroActual = 'todas';
let tareaActiva  = null;
let pasoActual   = 0;

/* ── Inicializar: obtener usuario y cargar datos ── */
async function init() {
  // Intentar obtener usuario autenticado
  const { data: { user } } = await sb.auth.getUser();
  usuarioId = user?.id ?? null;

  await cargarTareas();
  if (usuarioId) await cargarProgreso();
  renderLista();
}

/* ── Cargar tareas con sus pasos ── */
async function cargarTareas() {
  const { data, error } = await sb
    .from('tareas')
    .select('*, pasos(*)')
    .order('titulo', { ascending: true });

  if (error) { console.error('Error cargando tareas:', error.message); return; }

  tareas = data.map(t => ({
    ...t,
    pasos: (t.pasos || []).sort((a, b) => a.orden - b.orden)
  }));
}

/* ── Cargar registros_progreso del usuario actual ── */
async function cargarProgreso() {
  if (!usuarioId) return;

  const { data, error } = await sb
    .from('registros_progreso')
    .select('paso_id, estado')
    .eq('usuario_id', usuarioId);

  if (error) { console.error('Error cargando progreso:', error.message); return; }

  progreso = {};
  (data || []).forEach(r => { progreso[r.paso_id] = r.estado; });
}

/* ── Estado de un paso para el usuario actual ── */
function estadoPaso(pasoId) {
  return progreso[pasoId] || 'pendiente';
}

/* ── Calcular progreso de una tarea ── */
function calcProgreso(pasos) {
  const total  = (pasos || []).length;
  const hechos = (pasos || []).filter(p => estadoPaso(p.id) === 'completado').length;
  const pct    = total > 0 ? Math.round((hechos / total) * 100) : 0;
  return { total, hechos, pct };
}

/* ── Estado general de la tarea (basado en progreso del usuario) ── */
function estadoTarea(pasos) {
  if (!pasos || pasos.length === 0) return 'pendiente';
  const todos = pasos.every(p => estadoPaso(p.id) === 'completado');
  const alguno = pasos.some(p => estadoPaso(p.id) === 'completado');
  if (todos)  return 'completado';
  if (alguno) return 'en_progreso';
  return 'pendiente';
}

/* ── SVG helpers ── */
function svgCheck() {
  return `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
    <circle cx="50" cy="50" r="45" fill="#009E73"/>
    <path d="M25 50 L42 67 L75 33" stroke="white" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}
function svgTask(estado) {
  const color = estado === 'completado' ? '#009E73' : estado === 'en_progreso' ? '#0072B2' : '#A09080';
  return `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
    <rect x="15" y="10" width="70" height="80" rx="10" fill="${color}" opacity="0.2" stroke="${color}" stroke-width="4"/>
    <rect x="28" y="30" width="44" height="7" rx="3.5" fill="${color}"/>
    <rect x="28" y="46" width="35" height="7" rx="3.5" fill="${color}"/>
    <rect x="28" y="62" width="26" height="7" rx="3.5" fill="${color}"/>
  </svg>`;
}

function htmlBadge(estado) {
  const cfg = {
    completado:  { cls: 'estado-completado',  label: '✓ Listo' },
    en_progreso: { cls: 'estado-en_progreso', label: '▶ En curso' },
    pendiente:   { cls: 'estado-pendiente',   label: '○ Pendiente' },
  };
  const c = cfg[estado] || cfg.pendiente;
  return `<span class="estado-badge ${c.cls}">${c.label}</span>`;
}

/* ══ RENDER LISTA ══ */
function renderLista() {
  const lista      = document.getElementById('lista-tareas');
  const vacia      = document.getElementById('lista-vacia');
  const totalBadge = document.getElementById('total-completadas');

  totalBadge.textContent = tareas.filter(t => estadoTarea(t.pasos) === 'completado').length;

  const filtradas = tareas.filter(t => {
    if (filtroActual === 'todas') return true;
    return estadoTarea(t.pasos) === filtroActual;
  });

  lista.innerHTML = '';

  if (filtradas.length === 0) { vacia.classList.remove('hidden'); return; }
  vacia.classList.add('hidden');

  filtradas.forEach(tarea => {
    const estado = estadoTarea(tarea.pasos);
    const { total, hechos, pct } = calcProgreso(tarea.pasos);

    const btn = document.createElement('button');
    btn.className = 'tarjeta-tarea';
    btn.setAttribute('aria-label', `Abrir tarea: ${tarea.titulo}`);
    btn.innerHTML = `
      <div class="tarjeta-picto">${svgTask(estado)}</div>
      <div class="tarjeta-body">
        <div class="tarjeta-row">
          <h3 class="tarjeta-titulo">${tarea.titulo}</h3>
          ${htmlBadge(estado)}
        </div>
        <p class="tarjeta-desc">${tarea.descripcion || ''}</p>
        <div class="barra-progreso-wrap">
          <div class="barra-meta">
            <span class="barra-hechos-label">${hechos} de ${total} pasos</span>
            <span class="barra-pct-label">${pct}%</span>
          </div>
          <div class="barra-track"><div class="barra-fill" style="width:${pct}%"></div></div>
        </div>
      </div>
    `;
    btn.addEventListener('click', () => abrirDetalle(tarea.id));
    lista.appendChild(btn);
  });
}

/* ══ DETALLE ══ */
function abrirDetalle(tareaId) {
  tareaActiva = tareas.find(t => t.id === tareaId);
  if (!tareaActiva) return;
  const primerPendiente = tareaActiva.pasos.findIndex(p => estadoPaso(p.id) !== 'completado');
  pasoActual = primerPendiente >= 0 ? primerPendiente : 0;
  document.getElementById('vista-lista').classList.add('hidden');
  document.getElementById('vista-detalle').classList.remove('hidden');
  window.scrollTo(0, 0);
  renderDetalle();
}

function renderDetalle() {
  if (!tareaActiva) return;
  const pasos = tareaActiva.pasos;
  const paso  = pasos[pasoActual];
  const { total, hechos, pct } = calcProgreso(pasos);
  const estadoActual = estadoPaso(paso.id);

  document.getElementById('detalle-titulo').textContent = tareaActiva.titulo;
  document.getElementById('barra-hechos').textContent   = `${hechos} de ${total} pasos`;
  document.getElementById('barra-pct').textContent      = `${pct}%`;
  document.getElementById('barra-fill').style.width     = `${pct}%`;

  // Bolitas indicadoras
  const indicador = document.getElementById('indicador-pasos');
  indicador.innerHTML = '';
  pasos.forEach((p, i) => {
    const completado = estadoPaso(p.id) === 'completado';
    const b = document.createElement('button');
    b.className = 'paso-bolita';
    b.setAttribute('role', 'listitem');
    b.setAttribute('aria-label', `Paso ${i + 1}`);
    if (completado)    b.classList.add('completado');
    if (i === pasoActual) b.classList.add('activo');
    b.textContent = completado ? '✓' : i + 1;
    b.addEventListener('click', () => { pasoActual = i; renderDetalle(); });
    indicador.appendChild(b);
  });

  // Número de paso
  const circulo = document.getElementById('paso-num-circulo');
  circulo.textContent = estadoActual === 'completado' ? '✓' : paso.orden;
  circulo.className   = 'paso-num-circulo' + (estadoActual === 'completado' ? ' completado' : '');

  document.getElementById('paso-de').textContent = `Paso ${paso.orden} de ${total}`;
  paso.es_critico
    ? document.getElementById('paso-critico').classList.remove('hidden')
    : document.getElementById('paso-critico').classList.add('hidden');

  // Pictograma
  const pictoArea = document.getElementById('picto-area');
  const pictoHint = document.querySelector('.picto-hint');
  if (paso.imagen_url) {
    pictoArea.innerHTML = `<img src="${paso.imagen_url}" alt="${paso.instruccion_texto}" style="max-height:180px;border-radius:12px;object-fit:contain;"/>`;
    pictoHint.style.display = 'none';
  } else {
    pictoArea.innerHTML = estadoActual === 'completado' ? svgCheck() : svgTask(estadoActual);
    pictoHint.style.display = '';
  }

  document.getElementById('instruccion-texto').textContent = paso.instruccion_texto;
  document.getElementById('msg-enviado').classList.add('hidden');

  estadoActual === 'completado'
    ? document.getElementById('btn-completar').classList.add('hidden')
    : document.getElementById('btn-completar').classList.remove('hidden');

  document.getElementById('btn-anterior').disabled = pasoActual === 0;
  document.getElementById('btn-siguiente').disabled = pasoActual === pasos.length - 1;
}

/* ══ COMPLETAR PASO → upsert en registros_progreso ══ */
async function completarPaso(pasoId) {
  if (!usuarioId) {
    // Sin autenticación: guardar solo en memoria para demostración
    progreso[pasoId] = 'completado';
    return;
  }

  // Buscar si ya existe registro
  const { data: existente } = await sb
    .from('registros_progreso')
    .select('id')
    .eq('usuario_id', usuarioId)
    .eq('paso_id', pasoId)
    .maybeSingle();

  if (existente) {
    // Actualizar registro existente
    await sb.from('registros_progreso')
      .update({ estado: 'completado', fecha_fin: new Date().toISOString() })
      .eq('id', existente.id);
  } else {
    // Crear nuevo registro
    await sb.from('registros_progreso')
      .insert({
        usuario_id:   usuarioId,
        paso_id:      pasoId,
        estado:       'completado',
        fecha_inicio: new Date().toISOString(),
        fecha_fin:    new Date().toISOString(),
      });
  }

  progreso[pasoId] = 'completado';
}

/* ══ EVENTOS DETALLE ══ */
document.getElementById('btn-volver').addEventListener('click', () => {
  document.getElementById('vista-detalle').classList.add('hidden');
  document.getElementById('vista-lista').classList.remove('hidden');
  tareaActiva = null;
  renderLista();
});

document.getElementById('btn-completar').addEventListener('click', async () => {
  if (!tareaActiva) return;
  const paso = tareaActiva.pasos[pasoActual];
  await completarPaso(paso.id);
  if (pasoActual < tareaActiva.pasos.length - 1) pasoActual++;
  renderDetalle();
});

document.getElementById('btn-anterior').addEventListener('click', () => {
  if (pasoActual > 0) { pasoActual--; renderDetalle(); }
});
document.getElementById('btn-siguiente').addEventListener('click', () => {
  if (tareaActiva && pasoActual < tareaActiva.pasos.length - 1) { pasoActual++; renderDetalle(); }
});

document.getElementById('btn-ayuda').addEventListener('click', () => {
  if (!tareaActiva) return;
  const paso = tareaActiva.pasos[pasoActual];
  document.getElementById('modal-subtitulo').textContent = `Paso ${paso.orden}: ${paso.instruccion_texto}`;
  document.getElementById('modal-textarea').value = '';
  document.getElementById('modal-enviar').disabled = true;
  document.getElementById('modal-ayuda').classList.remove('hidden');
  document.getElementById('modal-textarea').focus();
});

/* ══ MODAL AYUDA ══ */
function cerrarModal() { document.getElementById('modal-ayuda').classList.add('hidden'); }
document.getElementById('modal-cancelar').addEventListener('click', cerrarModal);
document.getElementById('modal-ayuda').addEventListener('click', e => { if (e.target === e.currentTarget) cerrarModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarModal(); });
document.getElementById('modal-textarea').addEventListener('input', function () {
  document.getElementById('modal-enviar').disabled = !this.value.trim();
});

/* Enviar ayuda — notificaciones desactivadas por ahora */
document.getElementById('modal-enviar').addEventListener('click', () => {
  cerrarModal();
  const msgEl = document.getElementById('msg-enviado');
  msgEl.classList.remove('hidden');
  setTimeout(() => msgEl.classList.add('hidden'), 3000);
});

/* ══ FILTROS ══ */
document.querySelectorAll('.filtro-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    filtroActual = this.dataset.filtro;
    renderLista();
  });
});

/* ══ INIT ══ */
init();
