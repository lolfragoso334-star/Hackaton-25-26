/* ══════════════════════════════════════════════════════════════
   CONFIGURACIÓN DE SUPABASE — NeuroVida
   ⚠ Pon aquí tus credenciales reales de Supabase
   Settings → API → Project URL + anon public key
══════════════════════════════════════════════════════════════ */
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL  = 'https://TU_PROJECT_ID.supabase.co';   // ← cambia esto
const SUPABASE_KEY  = 'TU_ANON_PUBLIC_KEY';                   // ← cambia esto

export const sb = createClient(SUPABASE_URL, SUPABASE_KEY);
