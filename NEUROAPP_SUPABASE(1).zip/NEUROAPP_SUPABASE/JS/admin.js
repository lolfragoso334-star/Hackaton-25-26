/* ══════════════════════════════════════════════════════════════
   PANEL ADMIN — NeuroVida
   Estructura real de Supabase:
     tareas  : id, titulo, descripcion, creado_por (uuid FK perfiles)
     pasos   : id, tarea_id, orden, instruccion_texto, imagen_url, es_critico
   El estado de cada paso lo gestiona registros_progreso, no pasos.
   En el panel admin solo creamos/editamos/borramos tareas y pasos.
══════════════════════════════════════════════════════════════ */
import { sb } from './supabase.js';

let tareas        = [];
let tareaEditando = null;
let tareaABorrar  = null;
let pasoTmpCount  = 1;

/* ══ HELPERS ══ */
function toast(msg, tipo = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className   = 'toast' + (tipo ? ' ' + tipo : '');
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add('hidden'), 2800);
}

function badgeHtml(pasos) {
  const n = (pasos || []).length;
  return `<span class="estado-badge estado-pendiente">${n} paso${n !== 1 ? 's' : ''}</span>`;
}

/* ══ CARGAR TAREAS ══ */
async function cargarTareas() {
  const { data, error } = await sb
    .from('tareas')
    .select('*, pasos(*)')
    .order('titulo', { ascending: true });

  if (error) { toast('❌ Error al cargar: ' + error.message, 'rojo'); return; }

  tareas = data.map(t => ({
    ...t,
    pasos: (t.pasos || []).sort((a, b) => a.orden - b.orden)
  }));

  renderLista();
}

/* ══ RENDER LISTA ══ */
function renderLista() {
  const lista = document.getElementById('lista-admin');
  const vacia = document.getElementById('lista-vacia');

  document.getElementById('stat-total').textContent = tareas.length;
  document.getElementById('stat-pasos').textContent =
    tareas.reduce((acc, t) => acc + (t.pasos || []).length, 0);

  lista.innerHTML = '';

  if (tareas.length === 0) { vacia.classList.remove('hidden'); return; }
  vacia.classList.add('hidden');

  tareas.forEach(tarea => {
    const totalPasos = (tarea.pasos || []).length;
    const card = document.createElement('div');
    card.className = 'admin-tarea-card' + (tareaEditando === tarea.id ? ' activa' : '');
    card.setAttribute('role', 'button');
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-label', `Editar tarea: ${tarea.titulo}`);

    card.innerHTML = `
      <div class="admin-card-top">
        <span class="admin-card-titulo">${tarea.titulo}</span>
        <div class="admin-card-actions">
          <button class="btn-card-accion editar" data-id="${tarea.id}" aria-label="Editar">✏️</button>
          <button class="btn-card-accion borrar" data-id="${tarea.id}" aria-label="Borrar">🗑️</button>
        </div>
      </div>
      <p class="admin-card-desc">${tarea.descripcion || 'Sin descripción'}</p>
      <div class="admin-card-meta">
        <div class="barra-mini-track"><div class="barra-mini-fill" style="width:100%"></div></div>
        <span class="admin-card-pasos">${totalPasos} paso${totalPasos !== 1 ? 's' : ''}</span>
      </div>
    `;

    card.addEventListener('click', e => { if (e.target.closest('.btn-card-accion')) return; abrirFormEditar(tarea.id); });
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') abrirFormEditar(tarea.id); });
    card.querySelector('.editar').addEventListener('click', e => { e.stopPropagation(); abrirFormEditar(tarea.id); });
    card.querySelector('.borrar').addEventListener('click', e => { e.stopPropagation(); confirmarBorrado(tarea.id); });
    lista.appendChild(card);
  });
}

/* ══ FORMULARIO ══ */
function abrirFormNueva() {
  tareaEditando = null;
  limpiarForm();
  document.getElementById('form-modo-label').textContent = '✨ Nueva tarea';
  document.getElementById('campo-estado').closest('.form-field').style.display = 'none'; // no hay estado en tareas
  document.getElementById('form-placeholder').classList.add('hidden');
  document.getElementById('form-tarea').classList.remove('hidden');
  document.getElementById('campo-titulo').focus();
}

function abrirFormEditar(id) {
  const tarea = tareas.find(t => t.id === id);
  if (!tarea) return;
  tareaEditando = id;
  document.getElementById('form-modo-label').textContent = '✏️ Editando tarea';
  document.getElementById('campo-titulo').value = tarea.titulo;
  document.getElementById('campo-desc').value   = tarea.descripcion || '';
  document.getElementById('campo-estado').closest('.form-field').style.display = 'none';

  const listaPasos = document.getElementById('lista-pasos');
  listaPasos.innerHTML = '';
  (tarea.pasos || []).forEach(p => añadirFilaPaso(p));
  actualizarContadorPasos();

  document.getElementById('form-placeholder').classList.add('hidden');
  document.getElementById('form-tarea').classList.remove('hidden');
  renderLista();
  document.getElementById('campo-titulo').focus();
}

function limpiarForm() {
  document.getElementById('campo-titulo').value = '';
  document.getElementById('campo-desc').value   = '';
  document.getElementById('lista-pasos').innerHTML = '';
  document.getElementById('campo-titulo').classList.remove('error');
  actualizarContadorPasos();
}

function cerrarForm() {
  tareaEditando = null;
  document.getElementById('form-tarea').classList.add('hidden');
  document.getElementById('form-placeholder').classList.remove('hidden');
  renderLista();
}

/* ── Pasos en el formulario ── */
function añadirFilaPaso(paso = null) {
  const listaPasos = document.getElementById('lista-pasos');
  const idx    = listaPasos.children.length + 1;
  const id     = paso ? paso.id : 'tmp-' + (pasoTmpCount++);
  const texto  = paso ? paso.instruccion_texto : '';
  const critico = paso ? paso.es_critico : false;

  const div = document.createElement('div');
  div.className = 'paso-item';
  div.dataset.pasoId = id;

  div.innerHTML = `
    <div class="paso-item-header">
      <span class="paso-drag" aria-hidden="true">⠿</span>
      <span class="paso-num-label">Paso ${idx}</span>
      <div class="paso-item-controls">
        <label class="paso-check-label">
          <input type="checkbox" class="paso-critico-check" ${critico ? 'checked' : ''}/>
          ⚠ Crítico
        </label>
        <button type="button" class="btn-eliminar-paso" aria-label="Eliminar paso">✕</button>
      </div>
    </div>
    <input type="text" class="paso-input" placeholder="Describe este paso..."
      value="${texto.replace(/"/g, '&quot;')}" maxlength="160"/>
  `;

  div.querySelector('.btn-eliminar-paso').addEventListener('click', () => {
    div.remove(); renumerarPasos(); actualizarContadorPasos();
  });
  listaPasos.appendChild(div);
  actualizarContadorPasos();
  if (!paso) div.querySelector('.paso-input').focus();
}

function renumerarPasos() {
  document.querySelectorAll('.paso-item').forEach((el, i) => {
    el.querySelector('.paso-num-label').textContent = `Paso ${i + 1}`;
  });
}
function actualizarContadorPasos() {
  const n = document.getElementById('lista-pasos').children.length;
  document.getElementById('pasos-count').textContent = `${n} paso${n !== 1 ? 's' : ''}`;
}

/* ══ GUARDAR (INSERT / UPDATE) ══ */
document.getElementById('form-tarea').addEventListener('submit', async e => {
  e.preventDefault();

  const titulo = document.getElementById('campo-titulo').value.trim();
  if (!titulo) {
    document.getElementById('campo-titulo').classList.add('error');
    document.getElementById('campo-titulo').focus();
    toast('⚠ El título es obligatorio', 'rojo');
    return;
  }
  document.getElementById('campo-titulo').classList.remove('error');
  const desc = document.getElementById('campo-desc').value.trim();

  const filasPasos = document.querySelectorAll('.paso-item');
  let hayError = false;
  const pasosForm = Array.from(filasPasos).map((el, i) => {
    const input   = el.querySelector('.paso-input');
    const texto   = input.value.trim();
    const critico = el.querySelector('.paso-critico-check').checked;
    if (!texto) { input.classList.add('error'); hayError = true; }
    else          input.classList.remove('error');
    return { orden: i + 1, instruccion_texto: texto, imagen_url: null, es_critico: critico };
  });
  if (hayError) { toast('⚠ Rellena todos los pasos o elimínalos', 'rojo'); return; }

  const btn = document.getElementById('btn-guardar');
  btn.disabled = true; btn.textContent = 'Guardando…';

  try {
    if (tareaEditando) {
      /* ── UPDATE tarea ── */
      const { error: e1 } = await sb.from('tareas')
        .update({ titulo, descripcion: desc })
        .eq('id', tareaEditando);
      if (e1) throw e1;

      /* Borrar pasos anteriores y reinsertar */
      const { error: e2 } = await sb.from('pasos').delete().eq('tarea_id', tareaEditando);
      if (e2) throw e2;

      if (pasosForm.length > 0) {
        const { error: e3 } = await sb.from('pasos').insert(
          pasosForm.map(p => ({ ...p, tarea_id: tareaEditando }))
        );
        if (e3) throw e3;
      }
      toast('✅ Tarea actualizada', 'verde');

    } else {
      /* ── INSERT tarea ── */
      // Obtener usuario actual para rellenar creado_por
      const { data: { user } } = await sb.auth.getUser();

      const { data: td, error: e1 } = await sb.from('tareas')
        .insert({ titulo, descripcion: desc, creado_por: user?.id ?? null })
        .select()
        .single();
      if (e1) throw e1;

      if (pasosForm.length > 0) {
        const { error: e2 } = await sb.from('pasos').insert(
          pasosForm.map(p => ({ ...p, tarea_id: td.id }))
        );
        if (e2) throw e2;
      }
      toast('✅ Tarea creada', 'verde');
    }

    cerrarForm();
    await cargarTareas();

  } catch (err) {
    toast('❌ Error: ' + (err.message || err), 'rojo');
  } finally {
    btn.disabled = false; btn.textContent = '💾 Guardar tarea';
  }
});

/* ══ BORRAR ══ */
function confirmarBorrado(id) {
  tareaABorrar = id;
  document.getElementById('modal-borrar').classList.remove('hidden');
}
document.getElementById('modal-borrar-cancelar').addEventListener('click', () => {
  tareaABorrar = null; document.getElementById('modal-borrar').classList.add('hidden');
});
document.getElementById('modal-borrar-confirmar').addEventListener('click', async () => {
  if (!tareaABorrar) return;
  // Los pasos se borran en cascada por FK ON DELETE CASCADE
  const { error } = await sb.from('tareas').delete().eq('id', tareaABorrar);
  if (error) { toast('❌ Error al borrar: ' + error.message, 'rojo'); return; }
  if (tareaEditando === tareaABorrar) cerrarForm();
  tareaABorrar = null;
  document.getElementById('modal-borrar').classList.add('hidden');
  toast('🗑️ Tarea eliminada', 'rojo');
  await cargarTareas();
});
document.getElementById('modal-borrar').addEventListener('click', e => {
  if (e.target === e.currentTarget) { tareaABorrar = null; e.currentTarget.classList.add('hidden'); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { tareaABorrar = null; document.getElementById('modal-borrar').classList.add('hidden'); }
});

/* ══ NOTIFICACIONES — desactivadas por ahora ══ */
document.getElementById('btn-campana').addEventListener('click', () => {
  toast('ℹ️ Notificaciones próximamente');
});

/* ══ INIT ══ */
document.getElementById('btn-nueva-tarea').addEventListener('click', abrirFormNueva);
document.getElementById('btn-add-paso').addEventListener('click', () => añadirFilaPaso());
document.getElementById('btn-cancelar-form').addEventListener('click', cerrarForm);

cargarTareas();
